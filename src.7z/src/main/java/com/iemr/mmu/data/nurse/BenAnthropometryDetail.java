package com.iemr.mmu.data.nurse;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "t_phy_anthropometry")
public class BenAnthropometryDetail {
	@Id
	@GeneratedValue
	@Expose
	@Column(name = "ID")
	private Long ID;

	@Expose
	@Column(name = "BeneficiaryRegID")
	private Long beneficiaryRegID;
	
	@Expose
	@Column(name = "BenVisitID")
	private Long benVisitID;
	@Expose
	@Column(name = "ProviderServiceMapID")
	private Integer providerServiceMapID;
	@Expose
	@Column(name = "Weight_Kg")
	private Double weight_Kg;
	@Expose
	@Column(name = "Height_cm")
	private Double height_cm;
	@Expose
	@Column(name = "BMI")
	private Double bMI;
	@Expose
	@Column(name = "HeadCircumference_cm")
	private Double headCircumference_cm;
	@Expose
	@Column(name = "MidUpperArmCircumference_MUAC_cm")
	private Double midUpperArmCircumference_MUAC_cm;
	@Expose
	@Column(name = "HipCircumference_cm")
	private Double hipCircumference_cm;
	@Expose
	@Column(name = "WaistCircumference_cm")
	private Double waistCircumference_cm;
	@Expose
	@Column(name = "WaistHipRatio")
	private Double waistHipRatio;
	@Expose
	@Column(name = "Deleted", insertable = false, updatable = true)
	private Boolean deleted;
	@Expose
	@Column(name = "Processed", insertable = false, updatable = true)
	private String processed;
	@Expose
	@Column(name = "CreatedBy")
	private String createdBy;
	@Expose
	@Column(name = "CreatedDate", insertable = false, updatable = false)
	private Timestamp createdDate;
	@Expose
	@Column(name = "ModifiedBy")
	private String modifiedBy;
	@Expose
	@Column(name = "LastModDate", insertable = false, updatable = false)
	private Timestamp lastModDate;
	
	public BenAnthropometryDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Long getBeneficiaryRegID() {
		return beneficiaryRegID;
	}
	public void setBeneficiaryRegID(Long beneficiaryRegID) {
		this.beneficiaryRegID = beneficiaryRegID;
	}
	public Long getBenVisitID() {
		return benVisitID;
	}
	public void setBenVisitID(Long benVisitID) {
		this.benVisitID = benVisitID;
	}
	public Integer getProviderServiceMapID() {
		return providerServiceMapID;
	}
	public void setProviderServiceMapID(Integer providerServiceMapID) {
		this.providerServiceMapID = providerServiceMapID;
	}
	public Double getWeight_Kg() {
		return weight_Kg;
	}
	public void setWeight_Kg(Double weight_Kg) {
		this.weight_Kg = weight_Kg;
	}
	public Double getHeight_cm() {
		return height_cm;
	}
	public void setHeight_cm(Double height_cm) {
		this.height_cm = height_cm;
	}
	public Double getbMI() {
		return bMI;
	}
	public void setbMI(Double bMI) {
		this.bMI = bMI;
	}
	public Double getHeadCircumference_cm() {
		return headCircumference_cm;
	}
	public void setHeadCircumference_cm(Double headCircumference_cm) {
		this.headCircumference_cm = headCircumference_cm;
	}
	public Double getMidUpperArmCircumference_MUAC_cm() {
		return midUpperArmCircumference_MUAC_cm;
	}
	public void setMidUpperArmCircumference_MUAC_cm(Double midUpperArmCircumference_MUAC_cm) {
		this.midUpperArmCircumference_MUAC_cm = midUpperArmCircumference_MUAC_cm;
	}
	public Double getHipCircumference_cm() {
		return hipCircumference_cm;
	}
	public void setHipCircumference_cm(Double hipCircumference_cm) {
		this.hipCircumference_cm = hipCircumference_cm;
	}
	public Double getWaistCircumference_cm() {
		return waistCircumference_cm;
	}
	public void setWaistCircumference_cm(Double waistCircumference_cm) {
		this.waistCircumference_cm = waistCircumference_cm;
	}
	public Double getWaistHipRatio() {
		return waistHipRatio;
	}
	public void setWaistHipRatio(Double waistHipRatio) {
		this.waistHipRatio = waistHipRatio;
	}
	public Boolean getDeleted() {
		return deleted;
	}
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
	public String getProcessed() {
		return processed;
	}
	public void setProcessed(String processed) {
		this.processed = processed;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getLastModDate() {
		return lastModDate;
	}
	public void setLastModDate(Timestamp lastModDate) {
		this.lastModDate = lastModDate;
	}
	public Long getID() {
		return ID;
	}
	
	
	
}
