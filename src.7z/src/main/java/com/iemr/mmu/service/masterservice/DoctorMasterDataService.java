package com.iemr.mmu.service.masterservice;

public interface DoctorMasterDataService {

}
