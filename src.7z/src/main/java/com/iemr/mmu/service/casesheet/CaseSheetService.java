package com.iemr.mmu.service.casesheet;

public interface CaseSheetService {

}
