package com.iemr.mmu.service.masterservice;

import com.iemr.mmu.data.registrar.BeneficiaryData;

public interface RegistrarServiceMasterData {

	String getBenDetailsByRegID(Long beneficiaryRegID);
}
